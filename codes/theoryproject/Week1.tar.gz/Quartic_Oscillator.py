import numpy as np
import matplotlib.pyplot as plt
#this codes uses the RK4 method to integrate the 
# EoM for the harmonic oscilator with mass 1
# and frequency squared om2
# makes extenive use of numpy arrays (extension of python lists)
# plt.ion() # too laggy

# same as before, introduced lambda and changed the derivation function

# The Equation

# \ddot{x} = -om2(x + lmda x^3)

# Initial conditions
om2=1                # omega squared
lmda=-20             # lambda
t=0                  # time start
h=0.01               # step size
steps=2000           # number of steps to take
y=np.array([0.2,0])  # starting value for x, \dot{x}

#function to calculate derivatives for Quartic Oscillator
def deriv(y,t):
    return np.array([y[1],-om2*(y[0]+lmda*(y[0]**3))])

#rk4 does a single RK4 step
def rk4(y,dy,t,h):
    k1=dy(y,t)
    k2=dy(y+h/2*k1,t+h/2)
    k3=dy(y+h/2*k2,t+h/2)
    k4=dy(y+h*k3,t+h)
    y=y+h*(k1+2*k2+2*k3+k4)/6
    t=t+h
    return (t,y)
    
ts=np.array([t])     # to store all times
ys=np.array([y])     # and all solution points

for i in range(steps):  # take steps number of steps
    (t,y)=rk4(y,deriv,t,h)
    ts=np.append(ts,t)
    ys=np.concatenate((ys,np.array([y])))
#now plot it all
[y1,y2]=ys.transpose()


plt.figure()
plt.plot(ts,y2,label="velocity")
plt.plot(ts,y1,label="position")
plt.xlabel("time/[T]")
tks = np.arange(min(ts), max(ts)+1, (2)*np.pi/om2**(1/2))
ntks = tks.shape[0]

ticknames = range(ntks)
result = []
for number in ticknames:
    result.append(str(number) + "T")
plt.xticks(tks,result)
plt.ylabel("amplitude/[arbitrary units]")
plt.ylim([np.concatenate([y1,y2]).min(),np.concatenate([y1,y2]).max()])
plt.legend(loc="best")
plt.title("Position and velocity against time")


plt.figure()
plt.plot(y1,y2)
plt.ylabel("Velocity/[m/s]")
plt.xlabel("Position/[m]")
plt.title("Velocity against position(phase space)")
plt.ylim(y2.min(),y2.max())
plt.show()
