import numpy as np
import matplotlib.pyplot as plt
#this codes uses the RK4 method to integrate the 
# EoM for the harmonic oscilator with mass 1
# and frequency squared om2
# makes extenive use of numpy arrays (extension of python lists)
# plt.ion() # too laggy

# The Equations
# \ddot{x1} = -om2x1 - lmda x2
# \ddot{x2} = -om2x2 - lmda x1

# Initial conditions
x1=-0.2              # position 1
x2=0.2               # position 2
x1dot=-0.3            # velocity 1
x2dot=0.3            # velocity 2
om1sq=20.0             # omega1 squared
om2sq=15.0             # omega2 squared
lmda=1.0             # lambda
t=0                  # time start
h=0.01               # step size
steps=20000           # number of steps to take


#function to calculate derivatives for h.osc.
def deriv(y,t):
    return np.array([y[1],-om1sq*y[0]-lmda*y[2],y[3],-om2sq*y[2]-lmda*y[0]])

#rk4 does a single RK4 step
def rk4(y,dy,t,h):
    k1=dy(y,t)
    k2=dy(y+h/2*k1,t+h/2)
    k3=dy(y+h/2*k2,t+h/2)
    k4=dy(y+h*k3,t+h)
    y=y+h*(k1+2*k2+2*k3+k4)/6
    t=t+h
    return (t,y)
    
y=np.array([x1,x1dot,x2,x2dot])  # starting value for x1, \dot{x1}, x2, \dot{x2}
ts=np.array([t])     # to store all times
ys=np.array([y])     # and all solution points

for i in range(steps):  # take steps number of steps
    (t,y)=rk4(y,deriv,t,h)
    ts=np.append(ts,t)
    ys=np.concatenate((ys,np.array([y])))

    
#now plot it all
[y1,y2,y3,y4]=ys.transpose()
plt.figure()

plt.rc('text', usetex=True)
plt.rc('font', family='serif')

plt.plot(ts,y2,label="velocity 1")
plt.plot(ts,y1,label="position 1")
plt.xlabel(r"$time/[T_1]$")
tks = np.arange(min(ts), max(ts)+1, (2)*np.pi/om1sq**(1/2))
ntks = tks.shape[0]

ticknames = range(ntks)
result = []
for number in ticknames:
    result.append(str(number) + "T")
plt.xticks(tks,result)
plt.ylabel("amplitude/[arbitrary units]")
plt.ylim([np.concatenate([y1,y2]).min(),np.concatenate([y1,y2]).max()])
plt.legend(loc="best")
plt.title("Position 1 and velocity 1 against time")


plt.figure()
plt.plot(y1,y2)
plt.ylabel("Velocity 1/[m/s]")
plt.xlabel("Position 1/[m]")
plt.title("Velocity 1 against position 1(phase space)")
plt.ylim(y2.min(),y2.max())

plt.figure()
plt.rc('text', usetex=True)
plt.rc('font', family='serif')

plt.plot(ts,y4,label="velocity 2")
plt.plot(ts,y3,label="position 2")
plt.xlabel(r"$time/[T_2]$")
tks = np.arange(min(ts), max(ts)+1, (2)*np.pi/om2sq**(1/2))
ntks = tks.shape[0]

ticknames = range(ntks)
result = []
for number in ticknames:
    result.append(str(number) + "T")
plt.xticks(tks,result)
plt.ylabel("amplitude/[arbitrary units]")
plt.ylim([np.concatenate([y3,y4]).min(),np.concatenate([y3,y4]).max()])
plt.legend(loc="best")
plt.title("Position 2 and velocity 2 against time")
plt.figure()
plt.plot(y3,y4)
plt.ylabel("Velocity 2/[m/s]")
plt.xlabel("Position 2/[m]")
plt.title("Velocity 2 against position 2(phase space)")
plt.ylim(y4.min(),y4.max())

plt.figure()
plt.plot(y1,y3)
plt.ylabel("Position 2/[m/s]")
plt.xlabel("Position 1/[m]")
plt.title("Position 2 against position 1(lissajous figures)")
plt.ylim(y3.min(),y3.max())


plt.figure()
plt.plot(y2,y4)
plt.ylabel("Velocity 2/[m/s]")
plt.xlabel("Velocity 1/[m]")
plt.title("Velocity 2 against Velocity 1(lissajous figures)")
plt.ylim(y4.min(),y4.max())
plt.show()
