# -*- coding: utf-8 -*-
"""
This is the  integral from 0 to 2 of \cos(x)^2
using monte carlo integration
"""
import numpy.random as rnd;
import numpy as np;

# function to integrate cos^2
def integrate(n):
    # average n values within the region and return
    return np.sum(pow(np.cos(rnd.uniform(0,1,size=n)),2))/n

SampleSize = 100

# take measurements and calculate the uncertainty within them
for i in range(1,8):
    N = pow(10,i)
    measurement = []
    measurement2 = []
    for j in range(int(SampleSize)):
        measurement.append(integrate(N))
    mean = np.average(measurement)
    sigma = np.std(measurement)
    print (N, ":", mean, ":", sigma)
