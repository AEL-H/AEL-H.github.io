# -*- coding: utf-8 -*-
"""
This code applies the Metropolis algorithm to the 
1D harmonic oscilator
"""
import numpy.random as rnd;
import numpy as np;
import matplotlib.pyplot as plt

y1 = [] # x axis
y2 = [] # y axis
color = [] # used to color the points

def V(x):# potential energy
    return (pow(x,2)/2 + np.exp(-8*pow(x,2)))
    
def P(beta,x): # Boltzmann factor
    return np.exp(-beta*V(x))

#do the Metrpolis random walk
def random_walk(xin,beta,n,measure):
    global P
    av=0
    av2=0
    x=xin
    rejected=0

    y1.append(xin)
    y2.append(measure(xin))
    color.append(1)

    for moves in range(n): # change to range for python 3
        move=rnd.uniform(-1,1)
        xnew=x+move
        propratio=P(beta,xnew)/P(beta,x)
        if propratio <1:
            if propratio <rnd.uniform(0,1):
                y1.append(xnew)
                y2.append(measure(xnew))
                color.append(0)     #black - rejected
                rejected+=1
                xnew=x
        x=xnew
        y1.append(x)
        y2.append(measure(x))
        color.append(100)   #white - accepted
        m=measure(x)
        av+=m
        av2+=m*m
        
        plt.scatter(y1,y2,c=color, cmap = 'gray',s=100,alpha=0.70)
        plt.pause(0.1)
        
    return [beta,rejected/(1.0*n),x,av/n,av2/n]
# generate and prettyprint some data
plt.ion()
plt.show()
plt.axis([-4, 4, -1, 5])
n=100

#print("beta	|2*beta*av/n|av2/n-av/n^2/(n-1)/av/n|rejected/n|x")
#for col1, col2, col3, col4, col5 in ([random_walk(rnd.uniform(-1,1),beta,n,V) 
#    for beta in np.arange(1.,4.1,0.5)]):
#        print ("%2f | %2f | %2f | %2f | %2f" % (col1,2*col1*col4,(col5-col4*col4)/(n-1)/col4,col2,col3))

random_walk(rnd.uniform(-1,1),1.0,n,V) # generate data