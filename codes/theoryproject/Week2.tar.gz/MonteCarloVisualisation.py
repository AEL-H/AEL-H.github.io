# -*- coding: utf-8 -*-
"""
This is the  way to evaluate the area of a circle 
using monte carlo integration with rejection
"""
import numpy.random as rnd;
import numpy as np;
import matplotlib.pyplot as plt;
from mpl_toolkits.mplot3d import Axes3D

#plt.ion()
#plt.show()

N = 3 # less than 3 for visualisation

def pi_sample(n):
    xs = []
    ys = []
    zs = []
    cs = []
    count=0;
    for i in range(n):
        sample=rnd.uniform(-1,1,size=N)
        x,y,z = sample
        if np.linalg.norm(sample)<=1:
            count+=1
            xs.append(x)
            ys.append(y)
            zs.append(z)
            cs.append('g')
        else:
            xs.append(x)
            ys.append(y)
            zs.append(z)
            cs.append('r')
    return xs,ys,zs,cs

for i in range(1,5):
    xs,ys,zs,cs = pi_sample(pow(10,i))
    fig = plt.figure(i)
    ax = fig.add_subplot(111,projection='3d')
    ax.scatter(xs,ys,zs,c=cs)
    plt.show()

