# -*- coding: utf-8 -*-
"""
The quartic anharmonic oscilator
"""
import numpy as np
import scipy as sp # may have to import scipy.linalg explicitly depending on your interpreter
import matplotlib.pyplot as plt


def h(m,n,lam):
    fac=lam/16.0
    if m-n==4:
        return fac*np.sqrt(1.0*(n+1)*(n+2)*(n+3)*(n+4))
    elif m-n==2:
        return fac*2*(3+2*n)*np.sqrt(1.0*(n+1)*(n+2))
    elif n==m:
        return fac*(3+6*n+6*n*n)+n+0.5
    elif m-n==-2:
        return fac*2*(2*n-1)*np.sqrt(1.0*n*(n-1))
    elif m-n==-4:
        return fac*np.sqrt(1.0*n*(n-1)*(n-2)*(n-3))
    else:
        return 0
def es(lam,N):
    mt=np.matrix([[h(m,n,lam) for m in range(N)]for n in range(N)])
    return sp.linalg.eigvalsh(mt)

xs = []
ys = []

for lam in np.arange(0.0,10.0,0.1):
    Evalues = es(lam,500)
    ys.append(np.amin(Evalues))
    xs.append(lam)
    
plt.plot(xs,ys)
plt.xlabel("$\lambda$")
plt.ylabel("Minimum Eigenvalue")
plt.title("Minimum Eigenvalue vs $\lambda$")
plt.show()
