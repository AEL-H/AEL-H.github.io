# -*- coding: utf-8 -*-
"""
The quartic anharmonic oscilator
"""
import numpy as np
import scipy as sp # may have to import scipy.linalg explicitly depending on your interpreter
import math

def h(m,n,lam):
    fac=lam/16.0
    if m-n==4:
        return fac*np.sqrt(1.0*(n+1)*(n+2)*(n+3)*(n+4))
    elif m-n==2:
        return fac*2*(3+2*n)*np.sqrt(1.0*(n+1)*(n+2))
    elif n==m:
        return fac*(3+6*n+6*n*n)+n+0.5
    elif m-n==-2:
        return fac*2*(2*n-1)*np.sqrt(1.0*n*(n-1))
    elif m-n==-4:
        return fac*np.sqrt(1.0*n*(n-1)*(n-2)*(n-3))
    else:
        return 0

def eigenvalues(lam,N):
    
    result = np.array([])
    mt=np.matrix([[h(m,n,lam) for m in range(N)]for n in range(N)]) # create NxN matrix    
    
    a = math.floor(N/2)    # size of even matrix
    b = math.ceil(N/2)     # size of odd matrix
    
    # initialise the smaller matrices
    odd = np.zeros((b,b))
    even = np.zeros((a,a))
    
    # populate odd matrix
    odd = mt[::2,::2]
    # populate even matrix
    even = mt[1::2,1::2]
    
    result = np.append(result,sp.linalg.eigvalsh(odd))
    result = np.append(result,sp.linalg.eigvalsh(even))    

    return result
    
print(eigenvalues(5,5000))
