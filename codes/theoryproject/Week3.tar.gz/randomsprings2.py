import numpy.random as rnd;
import numpy as np;
import matplotlib.pyplot as plt

# assumes 1D, fixed points at 0 and X

X = 2

N = 5 #number of free points we would like

k = [] # vector of k values

# populate the k-vector
for points in range(N+1):
    k.append(rnd.uniform(0,1))

matrix = np.zeros((N,N)) # coefficient matrix

# create the dependent variable values
vector = np.zeros(N)
vector[-1] = X*-k[-1]

for i in range(1,N+1):
    for j in range(1,N+1):
        if(i==j):
            matrix[i-1][j-1] = -k[i] - k[i-1]
        elif(i==j+1):
            matrix[i-1][j-1] = k[j]
        elif(i==j-1):
            matrix[i-1][j-1] = k[i]

x = np.linalg.solve(matrix,vector) # solve for equilibrium positions

# here we have now solved for the equilibrium positions
# now we obtain the potential energy and create the matrix of derivatives

derivatives = np.zeros((N,N))
for i in range(x.size):
    for j in range(x.size):
        if(i==j):
            derivatives[i][j] = k[i] + k[i+1]
            
        elif((i-j)==1):
            derivatives[i][j] = -k[i]
            
        elif((j-i)==1):
            derivatives[i][j] = -k[j]
        
        else:
            derivatives[i][j] = 0

eigenvalues,eigenvectors = np.linalg.eig(derivatives)




# problem is already solved, everything beyond here concerns visualisation

x=np.append(x,X) # include the fixed point at X
y=np.zeros(x.size)
plt.figure()
plt.scatter(0,0,s=200) # plot origin (fixed point)


for i in range(x.size):
    if(x[i]==X):
        plt.scatter(x[i],0,s=200) # plot x=X fixed point

    else:
        plt.scatter(x[i],0)

x = np.insert(x,0,0)
y = np.append(y,0)

for i in range(len(x)-1):
    plt.plot(x[i:i+2], y[i:i+2], alpha=0.5, linewidth=k[i]*10) # plot line segments as springs
    # spring constant is reflected in the thickness of the line
    # higher spring constant gives a thicker line
plt.show()

