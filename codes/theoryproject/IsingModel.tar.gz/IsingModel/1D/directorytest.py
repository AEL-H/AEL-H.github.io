
# -*- coding: utf-8 -*-
"""
Created on Sat Feb 27 13:28:58 2016

@author: amir

Code to obtain thermodynamic quantities and output them into csv files for later data analysis
"""
import os,sys
import numpy as np
import numpy.random as rnd
import matplotlib.pyplot as plt
#import scipy.constants as spc

# assume J/k_b = 1
J = 1 #spc.Boltzmann # spin coupling
#k = spc.Boltzmann
        
def RandomLattice(X,Y):
    lattice = 2*rnd.randint(2,size=(Y,X))-1
    return lattice

def interaction(spin1,spin2):
    return -J*spin1*spin2

def energy(currentSpin,spins):
    E = 0
    for spin in spins:
        E += interaction(currentSpin,spin)
    return E 

def LatticeEnergy(Lattice):
    Y, X = Lattice.shape
    E = 0
    EnergyGrid = np.zeros((Y,X))
    for y in range(Y):
        for x in range(X):
            spins = []
            currentSpin = Lattice[y][x]
            # check if we are on edges
            spins.append(Lattice[y][(x-1)%X])
            spins.append(Lattice[y][(x+1)%X])
            E += energy(currentSpin,spins)
            EnergyGrid[y][x] = energy(currentSpin,spins)
    return E/(2*X*Y), EnergyGrid

# Initialisation functions

def P(deltaE,Temp):
      return np.exp(-(deltaE)/(1.*Temp))  
    
def FlipSpin(currentSpin,spins,Temp): # determine if spin should be flipped
    E1 = energy(currentSpin,spins)
    deltaE = -2*E1
    if(deltaE<0):
        return -currentSpin
    else:
        prob = P(deltaE,Temp)
        if(rnd.rand()<prob):
            return -currentSpin
        else:
            return currentSpin



def getMag(lattice):
    mag = np.sum(lattice)
    return mag

# takes a single step
def MonteCarloStep(lattice,Temp):
    Y,X = lattice.shape
    sites = X*Y
    
    
    for site in range(sites):
        x = rnd.randint(X)
        y = rnd.randint(Y)
        currentSpin = lattice[y,x]
        adjacentSpins = []
        
        # append the two nearest neighbours
        adjacentSpins.append(lattice[y][(x-1)%X])
        adjacentSpins.append(lattice[y][(x+1)%X])
        
        # work out the new spin
        NewSpin = FlipSpin(currentSpin,adjacentSpins,Temp)
        # then assign the new spin
        lattice[y,x] = NewSpin
    return lattice


# main program            


# initial conditions

startTemp = 4
endTemp = 0.001
divisions = 100

Y = 1

for X in range(10000,10001):
    for REPEAT in range(1,11):
        
        name = str(X) + "x" + "graph" + "REPEAT" + str(REPEAT)
        os.mkdir(name)
        
        Temp = np.linspace(startTemp,endTemp,divisions)
        Energy = np.zeros(divisions)
        Magnetization = np.zeros(divisions)
        SpecificHeat = np.zeros(divisions)
        Susceptibility = np.zeros(divisions)

        # begin with random lattice
        config = RandomLattice(X,Y)

        # working with the lattice
        # for each temperature
        for m in range(Temp.size):
            E=M=E2=M2=0 # Energy, Magnetisation, EnergySq, MagnetisationSq

            eqmSteps = 1000
            #config = RandomLattice(X,Y)
            for i in range(eqmSteps):
                MonteCarloStep(config,Temp[m])

            mcSteps = 500
            for i in range(mcSteps):
                MonteCarloStep(config,Temp[m])
                Ene = LatticeEnergy(config)[0]
                Mag = getMag(config)
                
                E += Ene
                M += Mag
                M2 += Mag*Mag
                E2 += Ene*Ene
        
        # calculate the averages
            E /= mcSteps
            M /= mcSteps
            M2 /= mcSteps
            E2 /= mcSteps
    
            Energy[m] = E # energy per site
            Magnetization[m] = M # magnetisation per site
            SpecificHeat[m]   = ( E2 - E*E)/(Temp[m]*Temp[m])
            Susceptibility[m] = ( M2 - M*M)/(Temp[m])

        np.savetxt(os.path.join(name, "Energy.txt"),Energy, delimiter=",")
        np.savetxt(os.path.join(name, "Magnetisation.txt"),Magnetization, delimiter=",")
        np.savetxt(os.path.join(name, "SpecificHeat.txt"),SpecificHeat, delimiter=",")
        np.savetxt(os.path.join(name, "Susceptibility.txt"),Susceptibility, delimiter=",")
        np.savetxt(os.path.join(name, "Temperature.txt"),Temp, delimiter=",")




































