# -*- coding: utf-8 -*-
"""
Created on Sat Feb 27 13:28:58 2016

@author: amir

Program to look through data sets and determine critical temperature
"""
import os,sys
import numpy as np

x = []
T = []
T_err = []


Y = 1

for X in range(10000,10001):

    sample = []    
    
    for REPEAT in range(1,6):
        
        name = str(X) + "x" + "graph" + "REPEAT" + str(REPEAT)

        if os.path.exists(name):
            Susceptibility = np.loadtxt(name+"\Susceptibility.txt")
            Temperature = np.loadtxt(name+"\Temperature.txt")

            m = np.argmax(Susceptibility) # look at highest susceptibility and take index
            sample.append(Temperature[m]) # find corresponding temperature
            
    avgTemp = np.average(sample)
    stdDev = np.std(sample)
            
    print(str(X)+"x"+"\t"+str(avgTemp)+"\t"+str(stdDev))
    x.append(X)
    T.append(avgTemp)
    T_err.append(stdDev)

results = "RESULTS"
os.mkdir(results)
# output the results
np.savetxt(os.path.join(results, "size.txt"),x, delimiter=",")
np.savetxt(os.path.join(results, "CritTemp.txt"),T, delimiter=",")
np.savetxt(os.path.join(results, "CritTempError.txt"),T_err, delimiter=",")





























