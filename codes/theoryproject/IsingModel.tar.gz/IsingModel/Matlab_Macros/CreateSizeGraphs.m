N = importdata('size.txt')
T = importdata('CritTemp.txt')
T_Err = importdata('CritTempError.txt')

errorbar(1./N,T,T_Err)
LF = linearfit(1./N,T)

ymodel = LF(1,1).*N + LF(1,2)
deltay = T-ymodel
z = (deltay./T_Err).^2
chi2 = sum(z)
rchi2 = chi2./(length(N)-2)