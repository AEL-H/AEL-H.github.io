import functools
import numpy as np 
import numpy.random as rnd
import matplotlib.pyplot as plt

# generate a sierpinski triangle in string form
def sierpinski(n):
 
    def aggregate(TRIANGLE, I):
        SPACE = "0" * (2 ** I)
        return [SPACE+X+SPACE for X in TRIANGLE] + [X+"0"+X for X in TRIANGLE]
 
    return functools.reduce(aggregate, range(n), ["1"])
 
 # utilise sierpinski function to create the same structure but with random spins
def CreateSierpLattice(N):

    SIZE = 3**N
    lattice = np.zeros((2**N,2**(N+1)-1)) # create the necessary space
    
    a = sierpinski(N) # get the structure

    # fill the lattice
    ROW = 0
    for row in a:
        COLUMN = 0
        for spin in row:
            lattice[ROW][COLUMN] = int(spin)
            COLUMN += 1
        ROW += 1
        
    # now randomise the lattice
    
    for i in range(2**N):
        for j in range(2**(N+1)-1):
            if(lattice[i][j] == 1):
                lattice[i][j] = 2*rnd.randint(2)-1
                
    
        
    return lattice

#Crystal = CreateSierpLattice(3)
#print(Crystal)


#####################################################################



# assume J/k_b = 1
J = 1 #spc.Boltzmann # spin coupling
#k = spc.Boltzmann
        
# the rest of the simulation as before, but with a new type of lattice

def interaction(spin1,spin2):
    return -J*spin1*spin2

def energy(currentSpin,spins):
    E = 0
    for spin in spins:
        E += interaction(currentSpin,spin)
    return E 

def LatticeEnergy(Lattice):
    Y, X = Lattice.shape
    E = 0
    EnergyGrid = np.zeros((Y,X))
    for y in range(Y):
        for x in range(X):
            spins = []
            currentSpin = Lattice[y][x]
            # check if we are on edges
            spins.append(Lattice[(y-1)%Y][(x-1)%X])
            spins.append(Lattice[(y-1)%Y][(x+1)%X])
            spins.append(Lattice[(y+1)%Y][(x+1)%X])
            spins.append(Lattice[(y+1)%Y][(x-1)%X])
            E += energy(currentSpin,spins)
            EnergyGrid[y][x] = energy(currentSpin,spins)
    return E/(2*(3**N)), EnergyGrid

# Initialisation functions

def P(deltaE,Temp):
      return np.exp(-(deltaE)/(1.*Temp))  
    
def FlipSpin(currentSpin,spins,Temp): # determine if spin should be flipped
    E1 = energy(currentSpin,spins)
    deltaE = -2*E1
    if(deltaE<0):
        return -currentSpin
    else:
        prob = P(deltaE,Temp)
        if(rnd.rand()<prob):
            return -currentSpin
        else:
            return currentSpin



def getMag(lattice):
    mag = np.sum(lattice)/(3**N)
    return mag

# takes a single step
def MonteCarloStep(lattice,Temp):
    Y,X = lattice.shape
    sites = X*Y
    
    
    for site in range(sites):
        x = rnd.randint(X)
        y = rnd.randint(Y)
        currentSpin = lattice[y,x]
        if(currentSpin != 0):
            adjacentSpins = []
        
            # append the four nearest neighbours
            adjacentSpins.append(lattice[(y-1)%Y][(x-1)%X])
            adjacentSpins.append(lattice[(y-1)%Y][(x+1)%X])
            adjacentSpins.append(lattice[(y+1)%Y][(x+1)%X])
            adjacentSpins.append(lattice[(y+1)%Y][(x-1)%X])

        
            # work out the new spin
            NewSpin = FlipSpin(currentSpin,adjacentSpins,Temp)
            # then assign the new spin
            lattice[y,x] = NewSpin
            return lattice
        else:
            return MonteCarloStep(lattice,Temp)


# main program            

# initial conditions
N = 3
startTemp = 4
endTemp = 1
divisions = 300
'''*(startTemp-endTemp)'''

Temp = np.linspace(startTemp,endTemp,divisions)
Energy = np.zeros(divisions)
Magnetization = np.zeros(divisions)
SpecificHeat = np.zeros(divisions)
Susceptibility = np.zeros(divisions)

# begin with random lattice
config = CreateSierpLattice(N)

# working with the lattice
# for each temperature
for m in range(Temp.size):
    E=M=E2=M2=0 # Energy, Magnetisation, EnergySq, MagnetisationSq

    eqmSteps = 2000
    #config = RandomLattice(X,Y)
    for i in range(eqmSteps):
        MonteCarloStep(config,Temp[m])

    mcSteps = 2000
    for i in range(mcSteps):
        MonteCarloStep(config,Temp[m])
        Ene = LatticeEnergy(config)[0]
        Mag = getMag(config)
        
        E += Ene
        M += Mag
        M2 += Mag*Mag
        E2 += Ene*Ene
        
    # calculate the averages
    E /= mcSteps
    M /= mcSteps
    M2 /= mcSteps
    E2 /= mcSteps
    
    Energy[m] = E # energy per site
    Magnetization[m] = M # magnetisation per site
    SpecificHeat[m]   = ( E2 - E*E)/(Temp[m]*Temp[m])
    Susceptibility[m] = ( M2 - M*M)/(Temp[m])


# plot the energy and Magnetization
f = plt.figure(figsize=(18, 10), dpi=80, facecolor='w', edgecolor='k');    

sp =  f.add_subplot(2, 2, 1 );
plt.plot(Temp, Energy,'o', color="#A60628", label=' Energy');
plt.xlabel("Temperature (T)", fontsize=20);
plt.ylabel("Energy ", fontsize=20);

sp =  f.add_subplot(2, 2, 2 );
plt.plot(Temp, Magnetization, '*', label='Magnetization'); # absolute value of magnetisation
plt.xlabel("Temperature (T)", fontsize=20);
plt.ylabel("Magnetization ", fontsize=20);



sp =  f.add_subplot(2, 2, 3 );
plt.plot(Temp, SpecificHeat, 'd', color="black", label='Specific Heat');
plt.xlabel("Temperature (T)", fontsize=20);
plt.ylabel("Specific Heat ", fontsize=20);


sp =  f.add_subplot(2, 2, 4 );
plt.plot(Temp, Susceptibility, '+', color="green", label='Specific Heat');
plt.xlabel("Temperature (T)", fontsize=20);
plt.ylabel("Susceptibility", fontsize=20);

#plt.legend(loc='best', fontsize=15); 
