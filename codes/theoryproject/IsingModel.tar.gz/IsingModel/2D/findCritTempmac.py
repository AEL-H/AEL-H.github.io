# -*- coding: utf-8 -*-
"""
Created on Wed Apr 27 23:01:54 2016

@author: magnushall

Program to look through data sets and determine critical temperature
"""

import os,sys
import numpy as np
import matplotlib.pyplot as plt

Tctotal=[]
Tcdev=[]
Tc=[]
N=[]
for n in range(2,11):
    Tctemp=[]
    file="attempt"+str(n)+"/"
    for i in range(2,10):
        X=2*i
        name=file+str(X)+"x"+str(X)+"graph"
        if os.path.exists(name):
            Susceptibility = np.loadtxt(name+"/Susceptibility.txt")
            Temperature = np.loadtxt(name+"/Temperature.txt")
                
            m = np.argmax(Susceptibility) # look at highest susceptibility and take index
            Tctemp.append(Temperature[m]) # find corresponding temperature
    Tctotal.append(Tctemp)

for i in range(8):
    Tctemp=[]
    for n in range(9):
        Tctemp.append(Tctotal[n][i])
    Tc.append(np.mean(Tctemp))
    Tcdev.append(np.std(Tctemp))
for i in range(2,10):
    N.append(1/pow(2*i,2))
    

plt.errorbar(N,Tc,Tcdev)
plt.xlabel("1/N",fontsize=20)
plt.ylabel("Critical Temperature",fontsize=20)
plt.show()
        
    
    
        
        



