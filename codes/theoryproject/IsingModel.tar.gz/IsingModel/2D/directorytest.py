
# -*- coding: utf-8 -*-
"""
Created on Sat Feb 27 13:28:58 2016

@author: amir

Code to obtain thermodynamic quantities and output them into csv files for later data analysis
"""
import os,sys
import numpy as np
import numpy.random as rnd
import matplotlib.pyplot as plt
#import scipy.constants as spc

# assume J/k_b = 1
J = 1 #spc.Boltzmann # spin coupling
#k = spc.Boltzmann
        
def RandomLattice(X,Y):
    lattice = 2*rnd.randint(2,size=(Y,X))-1
    return lattice

def interaction(spin1,spin2):
    return -J*spin1*spin2

def energy(currentSpin,spins):
    E = 0
    for spin in spins:
        E += interaction(currentSpin,spin)
    return E 

def LatticeEnergy(Lattice):
    Y, X = Lattice.shape
    E = 0
    EnergyGrid = np.zeros((Y,X))
    for y in range(Y):
        for x in range(X):
            spins = []
            currentSpin = Lattice[y][x]
            # check if we are on edges
            spins.append(Lattice[y][(x-1)%X])
            spins.append(Lattice[(y-1)%Y][x])
            spins.append(Lattice[y][(x+1)%X])
            spins.append(Lattice[(y+1)%Y][x])
            E += energy(currentSpin,spins)
            EnergyGrid[y][x] = energy(currentSpin,spins)
    return E/4, EnergyGrid

# Initialisation functions

def P(deltaE,Temp):
      return np.exp(-(deltaE)/(1.*Temp))  
    
def FlipSpin(currentSpin,spins,Temp): # determine if spin should be flipped
    E1 = energy(currentSpin,spins)
    deltaE = -2*E1
    if(deltaE<0):
        return -currentSpin
    else:
        prob = P(deltaE,Temp)
        if(rnd.rand()<prob):
            return -currentSpin
        else:
            return currentSpin



def getMag(lattice):
    mag = np.sum(lattice)
    return mag

# takes a single step
def MonteCarloStep(lattice,Temp):
    Y,X = lattice.shape
    sites = X*Y
    
    
    for site in range(sites):
        x = rnd.randint(X)
        y = rnd.randint(Y)
        currentSpin = lattice[y,x]
        adjacentSpins = []
        
        # append the four nearest neighbours
        adjacentSpins.append(lattice[y][(x-1)%X])
        adjacentSpins.append(lattice[(y-1)%Y][x])
        adjacentSpins.append(lattice[y][(x+1)%X])
        adjacentSpins.append(lattice[(y+1)%Y][x])
        
        # work out the new spin
        NewSpin = FlipSpin(currentSpin,adjacentSpins,Temp)
        # then assign the new spin
        lattice[y,x] = NewSpin
    return lattice


# main program            


# initial conditions

startTemp = 4
endTemp = 1
divisions = 100
'''*(startTemp-endTemp)'''

for n in range(2,11):
    root="attempt" +str(n)
    os.mkdir(root)
    for i in range(2,10):
        X=i*2 
        name =str(X) + "x" + str(X) + "graph"
        os.mkdir(os.path.join(root,name))
        Temp = np.linspace(startTemp,endTemp,divisions)
        Energy = np.zeros(divisions)
        Magnetization = np.zeros(divisions)
        SpecificHeat = np.zeros(divisions)
        Susceptibility = np.zeros(divisions)
        susceptibilityerror=[]
    
        # begin with random lattice
        config = RandomLattice(X,X)
    
        # working with the lattice
        # for each temperature
        for m in range(Temp.size):
            E=M=E2=M2=0 # Energy, Magnetisation, EnergySq, MagnetisationSq
            Energytemp = []
            Energy2temp = []
            Magtemp = []
            Magdev=0
            Mag2dev=0
            Magdev2=0
            Mag2temp = []
            eqmSteps = 2000
            print(m)
            #config = RandomLattice(X,Y)
            for i in range(eqmSteps):
                MonteCarloStep(config,Temp[m])
    
            mcSteps = 2000
            for i in range(mcSteps):
                MonteCarloStep(config,Temp[m])
                Ene = LatticeEnergy(config)[0]
                Mag = getMag(config)
                    
                E += Ene
                M += Mag
                M2 += Mag*Mag
                E2 += Ene*Ene
                Magtemp.append(M)
                Mag2temp.append(M2)
                
                    
            # calculate the averages
            E /= mcSteps
            M /= mcSteps
            M2 /= mcSteps
            E2 /= mcSteps
            Magdev=np.std(Magtemp)
            Mag2dev=np.std(Mag2temp)        
            Magdev2=pow(2,0.5)*M*Magdev
            
            Energy[m] = E/(X*X) # energy per site
            Magnetization[m] = M/(X*X) # magnetisation per site
            SpecificHeat[m]   = ( E2 - E*E)/(X*X*Temp[m]*Temp[m])
            Susceptibility[m] = ( M2 - M*M)/(X*X*Temp[m])
            susceptibilityerror.append(pow((pow(Magdev2,2)+pow(Mag2dev,2)),0.5))
        np.savetxt(os.path.join(root,name,"Energy.txt"),Energy, delimiter=",")
        np.savetxt(os.path.join(root,name,"Magnetisation.txt"),Magnetization, delimiter=",")
        np.savetxt(os.path.join(root,name,"SpecificHeat.txt"),SpecificHeat, delimiter=",")
        np.savetxt(os.path.join(root,name,"Susceptibility.txt"),Susceptibility, delimiter=",")
        np.savetxt(os.path.join(root,name,"Temperature.txt"),Temp, delimiter=",")
        np.savetxt(os.path.join(root,name,"Susceptibilityerror.txt"),susceptibilityerror, delimiter=",")
    
