
# -*- coding: utf-8 -*-
"""
Created on Sat Feb 27 13:28:58 2016

@author: amir

Program to look through data sets and determine critical temperature
"""
import os,sys
import numpy as np
import numpy.random as rnd
import scipy

#Xmax=7
#Ymax=7
#Zmax=7

x = []
y = []
z = []

C = np.zeros((7,7,7))
Cerr = np.zeros((7,7,7))

for X in range(4,11):
    for random1 in range(1,2):
        for random2 in range(1,2):
            
            Y=X
            Z=X
            
            sample = []
            
            for REPEAT in range(1,6):
        
                name = str(X) + "x" +str(Y) + "x" +str(Z) + "graph" + "REPEAT" + str(REPEAT)
                if os.path.exists(name):
                    Susceptibility = np.loadtxt(name+"\Susceptibility.txt")
                    Temperature = np.loadtxt(name+"\Temperature.txt")

                    m = np.argmax(Susceptibility) # look at highest susceptibility and take index
                    sample.append(Temperature[m]) # find corresponding temperature
            # get the mean and standard deviation of the array
            avgTemp = np.average(sample)
            stdDev = np.std(sample)
            
            x.append(X)
            y.append(Y)
            z.append(Z)
            
            C[X-4][Y-4][Z-4] = avgTemp
            Cerr[X-4][Y-4][Z-4] = stdDev
            print(str(X)+"x"+str(Y)+"x"+str(Z)+"\t"+str(avgTemp)+"\t"+str(stdDev))




results = "RESULTS"
os.mkdir(results)

matfileC = 'Color.mat'
matfileCerr = 'ColorError.mat'
# output the results
np.savetxt(os.path.join(results, "x.txt"),x, delimiter=",")
np.savetxt(os.path.join(results, "y.txt"),y, delimiter=",")
np.savetxt(os.path.join(results, "z.txt"),z, delimiter=",")
scipy.io.savemat(os.path.join(results,matfileC), mdict={'Color': C}, oned_as='row')
scipy.io.savemat(os.path.join(results,matfileCerr), mdict={'ColorErr': Cerr}, oned_as='row')
































