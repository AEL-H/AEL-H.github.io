
# -*- coding: utf-8 -*-
"""
Created on Sat Feb 27 13:28:58 2016

@author: amir

Code to take the average and standard deviation for critical temperature from a set of results
"""
import os,sys
import numpy as np
import numpy.random as rnd

N = []
T = []
T_err = []


for X in range(4,15):
    for random1 in range(9,10):
        for random2 in range(9,10):
            Y=X
            Z=X
            sample = []
            
            for REPEAT in range(1,6):
        
                name = str(X) + "x" +str(Y) + "x" +str(Z) + "graph" + "REPEAT" + str(REPEAT)
                if os.path.exists(name):
                    Susceptibility = np.loadtxt(name+"\Susceptibility.txt")
                    Temperature = np.loadtxt(name+"\Temperature.txt")

                    m = np.argmax(Susceptibility) # look at highest susceptibility and take index
                    sample.append(Temperature[m]) # append corresponding temperature into an array
            
			# get the mean and standard deviation of the array
            avgTemp = np.average(sample)
            stdDev = np.std(sample)
            
            N.append(X*Y*Z)
            T.append(avgTemp)
            T_err.append(stdDev)
            
			# print the results
            print(str(X)+"x"+str(Y)+"x"+str(Z)+"\t"+str(avgTemp)+"\t"+str(stdDev))
#                np.savetxt(os.path.join(name, "Energy.txt"),Energy, delimiter=",")
 #               np.savetxt(os.path.join(name, "Magnetisation.txt"),Magnetization, delimiter=",")
  #              np.savetxt(os.path.join(name, "SpecificHeat.txt"),SpecificHeat, delimiter=",")
   #             np.savetxt(os.path.join(name, "Susceptibility.txt"),Susceptibility, delimiter=",")
    #            np.savetxt(os.path.join(name, "Temperature.txt"),Temp, delimiter=",")




results = "RESULTS"

if not os.path.exists(results):
    os.mkdir(results)



np.savetxt(os.path.join(results, "size.txt"),N, delimiter=",")
np.savetxt(os.path.join(results, "CritTemp.txt"),T, delimiter=",")
np.savetxt(os.path.join(results, "CritTempError.txt"),T_err, delimiter=",")
































